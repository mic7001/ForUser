此处放置Application.app 和 Application.crc
