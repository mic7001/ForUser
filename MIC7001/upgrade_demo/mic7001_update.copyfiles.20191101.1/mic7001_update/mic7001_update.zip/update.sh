#bin/sh
#This sh script is used for system update

cp -rfa /userdata/Store /media/sda1/

#####################################################################
